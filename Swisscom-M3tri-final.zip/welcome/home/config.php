<?php

$METRI_TOKEN = "https://api.telegram.org/bot1218896856:AAE4XIkLzhNk8rTEHUgVT4_uWF-u1rc_f4M";

$chat_id = "-533613434";

$reload = '3';

?>